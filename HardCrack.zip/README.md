This program has a goldberg downloader that downloads goldberg from the official website, but it downloads all the
files, thats fine though, if it fails with that download, please report it in my discord or try following the steps bellow.

1. https://mr_goldberg.gitlab.io/goldberg_emulator
press "latest build" and download it, you can place it anywhere but when extracting please have it in the same folder as
HardCrack.exe

2. (optional) When downloaded, you can delete everything in the goldberg folder, but save the steamp_api/64.dll's
3. launch and crack any steam game. (read bellow for more info)

Some games are not crackable with this, this type of program just replaces steam_api/64.dll with the gb (goldberg)
steam_api/64.dll, so not all games are crackable :(

I will add more emulators with this though, and run tests :)