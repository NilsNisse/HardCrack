import requests
import sys
import os
import zipfile
import io

def download_update(url):
    save_as = "HardCrack_new.exe"
    
    cwd = os.getcwd()
    hardCrack_path = os.path.join(cwd, "HardCrack.exe")
    modules_path = os.path.join(cwd, "modules")
    
    try:
        if os.path.exists(hardCrack_path) and os.path.exists(modules_path):
            sys.remove(hardCrack_path)
            sys.rem(modules_path)
        
        # download zip from the url
        response = requests.get(url, stream=True)
        response.raise_for_status()

        # open as a zip file (from memory)
        with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
            # extract all contents
            zip_ref.extractall(save_as)

        print(f"Downloaded and extracted to: {os.path.abspath(save_as)}")
    except Exception as e:
        print("ERROR:", e)
        
#https://www.mediafire.com/file/ug8vjdw881z129s/HardCrack.zip/file

def check_status():
    try:
        res = requests.get("http://77.105.218.23/downloads/HardCrack/td.txt", timeout=5)
        return res.text.strip().splitlines()
    except Exception as e:
        print("Update check failed:", e)
        return []

res = requests.get("http://77.105.218.23/downloads/HardCrack/td.txt") 

split_lines = check_status()

if split_lines == ["True", "False"] and requests.get("https://pastebin.com/edit/Ahs2d7nj").text == "V1.0.1b":
    download_update("http://77.105.218.23/downloads/HardCrack/HardCrack.exe")
