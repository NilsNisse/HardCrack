#from .__init__ import _fore

def _print(_str: str, print_type: str="[main.py]", _bool: bool=False, _a: str=""):
    #print(_a)
    
    if not isinstance(_str, str):
        _str = str(_str)
    
    if not isinstance(_str, str) and _bool == True:
        print(str(_str), _bool)
    elif isinstance(_str, str) and _bool == True:
        #print("_bool != False")
        
        print(print_type, _str,"(", _bool, ")")
    elif _a == "-n":
        print("\n" + print_type, _str)
    elif _a == "n-":
        print(print_type, _str + "\n")
    elif _a == "-r":
        print("\r" + print_type, _str)
    elif _a == "r-":
        print(print_type, _str + "\r")
    elif print_type == "-none":
        print(_str)
    elif print_type != "[main.py]":
        print(f"[{print_type}]", _str)
    else:
        print(print_type, _str)