import os
import ctypes
import time
import sys
import requests
import colorama
import subprocess
from ._find_file import _find_file
from colorama import Fore
colorama.init()


lines = """
┌───┐    ┌─┬─┐    ┌───┐
│   │    │ │ │    │   │
└───┘    └─┴─┘    └───┘
┬ ┴ ┼ ┤ ├

───┤ Section ├───

FAT:

╔═══╗    ╔═╦═╗    ╔═══╗
║   ║    ║ ║ ║    ║   ║
╚═══╝    ╚═╩═╝    ╚═══╝


╦ ╩ ╬ ╣ ╠
"""

res = requests.get("https://pastebin.com/raw/Ahs2d7nj").text

version = "V1.0.0b"

_title_text_ = f"""
 ╔──────────┬────────╗
 │HardCrack ║ {version}│
 ╚──────────┴────────╝
 
 1. Crack steam game
 2. Check for updates
 3. Restart
 4. Exit
"""

update_title_text_ = f"""
 ╔──────────┬────────╗
 │HardCrack ║ {version}│
 ╚──────────┴────────╝
 {Fore.GREEN}New update available: {res}{Fore.RESET}
 
 1. Crack steam game
 2. Update
 3. Restart
 4. Exit
"""

steam_api = "steam_api" # Even thought it's called steam_api without 64 it will find steam_api64.dll aswell.
api_type = ".dll"

def check_update():
    ver_res = requests.get("https://pastebin.com/raw/Ahs2d7nj")
    
    if ver_res.text == "V1.0.0b":
        return False
    elif ver_res.text != "V1.0.0b":
        return True

def cls():
    os.system("cls")

def set_title(_title):
    os.system(f"{_title}")

def _find_all(_path, _filename):
    _find_file(_path, _filename, api_type)

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def main():
    cls()
    print("Type 'exit' to go back.")
    
    ipt = input("Folder to search: ")
    
    if ipt.lower() == "exit":
        TUI()
    else:
        print("Command does not exist.")
        time.sleep(1.5)
        main()
    
    if os.path.exists(ipt) == False:
        print("This path does not exist.")
        time.sleep(1.5)
        main()
        
    try:
        _find_all(ipt, steam_api)
        input("\nPress any button to continue...")
        TUI()
    except Exception as f:
        print("ERROR ->", f)
        

def TUI():
    cls()
    
    if check_update() == True:
        print(update_title_text_)
    elif check_update() == False:
        print(_title_text_)
    
    ipt = input(" $ ")
    
    if ipt == "1":
        main()
    elif ipt == "2":
        print(" Checking...")
        if check_update() == False:
            print(" No new updates!")
            time.sleep(1.5)
            TUI()
        elif check_update() == True:
            print(" New update available.")
            return True
            
    elif ipt == "3":
        if sys.argv[0].endswith(".py"):
            subprocess.run([sys.executable, sys.argv[0]])
        else:
            subprocess.run([sys.argv[0]])
        sys.exit(0)
    elif ipt == "4":
        print(" Exiting...")
        time.sleep(0.7)
        sys.exit(0)


if is_admin() == True:
    set_title("title HardCrack ^| check out my github for more fun made projects.")
    pass
elif is_admin() == False:
    set_title("title HardCrack ^| check out my github for more fun made projects.")
    pass


if __name__ == "__main__":
    TUI()