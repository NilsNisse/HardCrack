import os
import shutil
import time
import requests
import zipfile
import io
from ._print import _print


def download_gb(url):
    response = requests.get(url)
    response.raise_for_status()  # raise an error if the download failed
    
    # 3. Open the downloaded content as a Zip file
    with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
        # 4. Extract all contents to a folder
        zip_ref.extractall("Goldberg_API")  # replace with your folder path
    
    print("Download and extraction complete!")

def _find_file(_path, _filename, _file_type):
    for dirpath, dirnames, filenames in os.walk(_path):
        for filename in filenames:
            if os.path.isdir(dirpath):
                if filename.startswith(_filename) and filename.endswith(_file_type):
                    _join_dirpath_filename = os.path.join(dirpath, filename)
                    #_print(f"File path: {_join_dirpath_filename}")
                    try:
                        if os.path.exists(_join_dirpath_filename) == True:
                            _print(f"File found: {_join_dirpath_filename}", print_type="-none")
                            
                            gb_folder = "Goldberg_API"
                            gb_file = "steam_api.dll"
                            gb64_file = "steam_api64.dll"
                            
                            gb_join = os.path.join(gb_folder, gb_file)
                            gb64_join = os.path.join(gb_folder, gb64_file)
                            
                            if os.path.exists(gb_join) == False and os.path.exists(gb64_join) == False:
                                print("Downloading gb steam_api's...")
                                download_gb("https://gitlab.com/Mr_Goldberg/goldberg_emulator/-/jobs/4247811310/artifacts/download")
                                

                            
                            if filename == "steam_api64.dll" and os.stat(_join_dirpath_filename).st_size < 1958900:
                                old_size = os.stat(_join_dirpath_filename).st_size
                                os.remove(_join_dirpath_filename)
                                print("Removed original steam_api64.dll")
                                time.sleep(0.7)
                                shutil.copy(gb64_join, _join_dirpath_filename)
                                new_size = os.stat(_join_dirpath_filename).st_size
                                print(f"st_size: {old_size} Byte -> {new_size} Byte\ngb_steam64_api.dll moved to new folder\nSuccessfully cracked the game.")
                            elif filename == "steam_api.dll" and os.stat(_join_dirpath_filename).st_size < 1488800:
                                old_size = os.stat(_join_dirpath_filename).st_size
                                os.remove(_join_dirpath_filename)
                                print("Removed original steam_api.dll")
                                time.sleep(0.7)
                                shutil.copy(gb_join, _join_dirpath_filename)
                                new_size = os.stat(_join_dirpath_filename).st_size
                                print(f"st_size: {old_size} Byte -> {new_size} Byte\ngb_steam_api.dll moved to new folder\nSuccessfully cracked the game.")
                            elif filename == "steam_api64.dll" and os.stat(_join_dirpath_filename).st_size > 1958900:
                                print("Seems like the gb steam_api64.dll already exists in this game folder.")
                            elif filename == "steam_api.dll" and os.stat(_join_dirpath_filename).st_size > 1488800:
                                print("Seems like the gb steam_api.dll already exists in this game folder.")
                                
                        elif os.path.exists(_join_dirpath_filename) == False:
                            _print(f"File not found: {_join_dirpath_filename}", print_type="-none")
                        else:
                            _print(f"Unknown if file found: {_join_dirpath_filename}", print_type="-none")
                        pass
                    except Exception as f:
                        print(f"WARNING: {f}\n")
                        continue
