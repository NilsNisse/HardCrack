import subprocess
import os
from modules.main_modules import TUI


def launch_updater():
    print(" Launching updater...")
    cwd = os.getcwd()
    joined_path = os.path.join(cwd, "updater.exe")
    
    subprocess.Popen(joined_path)
    #sys.exit(0)

if __name__ == "__main__":
    #TUI()
    
    if TUI() == True:
        launch_updater()